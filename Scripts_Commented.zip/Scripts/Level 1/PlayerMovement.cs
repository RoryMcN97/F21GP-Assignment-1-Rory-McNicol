﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public CharacterController controller; //link player character controller

    public float speed = 12f; //move speed
    public float gravity = -9.81f;
    public float JumpHeight = 3f;

    public Transform GroundCheck;
    public float GroundDistance = 0.4f; //radius of collider sphere
    public LayerMask GroundMask; //controls what objects sphere checks for

    Vector3 velocity;
    bool isGrounded;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        isGrounded = Physics.CheckSphere(GroundCheck.position, GroundDistance, GroundMask); //checks to see if can jumo again

        if(isGrounded && velocity.y < 0)
        {
            velocity.y = -2f; //set to -2 in case registered before player on ground
        }

        float x = Input.GetAxis("Horizontal");//Conect inputs
        float z = Input.GetAxis("Vertical"); //Connect inputs

        Vector3 move = transform.right * x +transform.forward * z; //Transform location accordingly
        
        controller.Move(move * speed * Time.deltaTime); //move and is framerate dependent

        if(Input.GetButtonDown("Jump")&& isGrounded)
        {
            velocity.y += Mathf.Sqrt(JumpHeight * -2 * gravity); //As v = sqrt(h*-2.g)
        }

        velocity.y += gravity * Time.deltaTime; //framerate control

        controller.Move(velocity * Time.deltaTime); //Times by Time delta.Time as "y2-y1 = 1/2*g.t^2" for accurate physics
    }
}
