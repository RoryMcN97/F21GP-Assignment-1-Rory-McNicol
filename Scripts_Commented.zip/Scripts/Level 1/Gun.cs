﻿using UnityEngine;

public class Gun : MonoBehaviour
{
    public float Damage = 10f; //Damage to target
    public float range = 100f; //Range of gun

    public Camera fpsCam;
    public ParticleSystem muzzleFlash; //effect

    // Update is called once per frame
    void Update()
    {
        if(Input.GetButtonDown("Fire1")) //from input manager
        {
            Shoot(); //call function
        }
    }

    void Shoot()
    {
        muzzleFlash.Play(); //effect customised in editor
        RaycastHit Hit; //detect with raycast if within range
        if (Physics.Raycast(fpsCam.transform.position, fpsCam.transform.forward, out Hit, range)) //shoot where mouse look
        {
            Debug.Log(Hit.transform.name); //log it

            Enemy Enemy = Hit.transform.GetComponent<Enemy>(); //this is all about sending damage value to enemy script so health can be deducted
            if (Enemy != null)
            {
                Enemy.TakeDamage(Damage);
            }
        }
    }
}
