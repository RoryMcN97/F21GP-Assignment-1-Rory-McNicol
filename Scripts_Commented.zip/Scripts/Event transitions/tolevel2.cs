﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class tolevel2 : MonoBehaviour
{
    public void Level2 ()
    {
        SceneManager.LoadScene("Level 2"); //transitions to level 2 on button click
    }
}
