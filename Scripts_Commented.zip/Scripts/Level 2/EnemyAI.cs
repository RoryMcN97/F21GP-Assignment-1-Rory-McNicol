﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.SceneManagement;

public class EnemyAI : MonoBehaviour
{
    public NavMeshAgent agent; //the cube
    public Transform player; //iggy or glu
    public LayerMask whatIsGround, whatIsPlayer; //detect layers

    //patrolling
    public Vector3 walkPoint;
    bool walkPointSet; //is wander?
    public float walkPointRange; //range of wander

    //Attacking
    public float timeBetweenAttacks; //not necessarly present in final result but suitable for future implementations
    bool alreadyAttacked; //dito

    //States
    public float sightRange, attackRange; // help manage states based on info gathered by enemy
    public bool playerInSightRange, playerInAttackRange; //simple conditions self explanatory

    private void Awake()
    {
        player = GameObject.Find("Player 2").transform;
        agent = GetComponent<NavMeshAgent>();
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        playerInSightRange = Physics.CheckSphere(transform.position, sightRange, whatIsPlayer);
        playerInAttackRange = Physics.CheckSphere(transform.position, attackRange, whatIsPlayer);

        if(!playerInSightRange && !playerInAttackRange)
        {
            Patrolling(); //state 1
        }

        if(playerInSightRange && !playerInAttackRange)
        {
            Chasing(); //state 2
        }

        if(playerInSightRange && playerInAttackRange)
        {
            Attacking(); //state 3
        }

    }

    private void Patrolling()
    {
        if(!walkPointSet) //not got walk point 
        {
            searchWalkPoint(); //start looking
        }
        if(walkPointSet) //got your walk point
        {
            agent.SetDestination(walkPoint); //go walk point
        }
        Vector3 distanceToWalkPoint = transform.position - walkPoint; //calculate distance and start the trek

        if(distanceToWalkPoint.magnitude < 1f) //close enough
        {
            walkPointSet = false; //new
        }
    }

    private void searchWalkPoint()
    {
        float randomZ = Random.Range(-walkPointRange, walkPointRange); //sets random walk point based on range
        float randomX = Random.Range(-walkPointRange, walkPointRange); //dito

        walkPoint = new Vector3(transform.position.x + randomX, transform.position.y, transform.position.z + randomZ); //walk to walk point

        if(Physics.Raycast(walkPoint, -transform.up, 2f, whatIsGround))
            {
            walkPointSet = true; //got your walk point
            }
    }

    private void Chasing() //found him
    {
        agent.SetDestination(player.position); //walk to player
    }

    private void Attacking() //get him
    {
        agent.SetDestination(transform.position); //position
        
        transform.LookAt(player); //angle to player

        SceneManager.LoadScene("Game Over"); //he caught you

        if(!alreadyAttacked) //alternative for cosmetics
        {
            //Attack requires simply turning on particle effect

            alreadyAttacked = true; //wait till next attack
            Invoke(nameof(resetAttacks), timeBetweenAttacks); //causes delay so not constantly called
        }
    }

    private void resetAttacks()
    {
        alreadyAttacked = false; //not too important just cosmetic (particle effect)
    }

}
