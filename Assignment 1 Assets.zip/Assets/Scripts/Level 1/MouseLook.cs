﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MouseLook : MonoBehaviour
{
    public float mouseSensitivity = 100f; //Sensitivity of mouse

    public Transform playerBody;    //body reference

    float xRotation = 0f;   //

    // Start is called before the first frame update
    void Start()
    {
        Cursor.lockState = CursorLockMode.Locked;   //Locks cursor to centre on start
    }

    // Update is called once per frame
    void Update()
    {
        float mouseX = Input.GetAxis("Mouse X") * mouseSensitivity * Time.deltaTime; //Time.deltaTime helps with framerate
        float mouseY = Input.GetAxis("Mouse Y") * mouseSensitivity * Time.deltaTime;

        xRotation -= mouseY;
        xRotation = Mathf.Clamp(xRotation, -90f, 90f); //Stops overrotation

        transform.localRotation = Quaternion.Euler(xRotation, 0f, 0f); //Quaternion are responsible for rotation
        playerBody.Rotate(Vector3.up * mouseX); //Rotate player around Y axis
    }
}
