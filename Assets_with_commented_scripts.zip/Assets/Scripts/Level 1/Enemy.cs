﻿using UnityEngine;

public class Enemy : MonoBehaviour
{
    public float health = 50f; //default health


    public void TakeDamage (float amount)
    {
        health -= amount; //decrease health by amount established in another script
        if(health <= 0f)
        {
            Die(); //perform die if health less than or equal to zero
        }
    }

    void Die()
    {
        Destroy(gameObject); //destroy object
        //alternative include particle effect and rag doll
    }
}
